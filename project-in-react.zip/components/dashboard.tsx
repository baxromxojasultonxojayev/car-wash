"use client"

import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { Card } from "@/components/ui/card"
import { Zap, Users, Building2, DollarSign } from "lucide-react"

const sessionData = [
  { name: "Monday", sessions: 120, revenue: 1200 },
  { name: "Tuesday", sessions: 132, revenue: 1400 },
  { name: "Wednesday", sessions: 101, revenue: 950 },
  { name: "Thursday", sessions: 98, revenue: 980 },
  { name: "Friday", sessions: 199, revenue: 2210 },
  { name: "Saturday", sessions: 200, revenue: 2290 },
  { name: "Sunday", sessions: 145, revenue: 1890 },
]

const paymentData = [
  { name: "RFID", value: 40, color: "#3b82f6" },
  { name: "Cash", value: 30, color: "#1e40af" },
  { name: "Payme", value: 20, color: "#1e3a8a" },
  { name: "Click", value: 10, color: "#0c4a6e" },
]

export default function Dashboard() {
  const stats = [
    {
      label: "Active Kiosks",
      value: "24",
      icon: Zap,
      color: "bg-blue-500/10 text-blue-400",
    },
    {
      label: "Total Users",
      value: "1,234",
      icon: Users,
      color: "bg-cyan-500/10 text-cyan-400",
    },
    {
      label: "Companies",
      value: "8",
      icon: Building2,
      color: "bg-purple-500/10 text-purple-400",
    },
    {
      label: "Today Revenue",
      value: "$4,280",
      icon: DollarSign,
      color: "bg-green-500/10 text-green-400",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.label} className="bg-card border border-border/20 p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-muted-foreground text-sm font-medium mb-2">{stat.label}</p>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <Icon size={24} />
                </div>
              </div>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-card border border-border/20 p-6">
          <h3 className="text-lg font-bold text-foreground mb-6">Weekly Revenue</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={sessionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
              <XAxis dataKey="name" stroke="rgba(148, 163, 184, 0.5)" />
              <YAxis stroke="rgba(148, 163, 184, 0.5)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(15, 23, 42, 0.95)",
                  border: "1px solid rgba(148, 163, 184, 0.2)",
                  borderRadius: "8px",
                  color: "#e2e8f0",
                }}
              />
              <Line
                type="monotone"
                dataKey="revenue"
                stroke="#3b82f6"
                dot={{ fill: "#3b82f6", r: 5 }}
                activeDot={{ r: 7 }}
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="bg-card border border-border/20 p-6">
          <h3 className="text-lg font-bold text-foreground mb-6">Payment Methods</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={paymentData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={2}
                dataKey="value"
              >
                {paymentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card className="bg-card border border-border/20 p-6">
        <h3 className="text-lg font-bold text-foreground mb-6">Wash Sessions</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={sessionData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
            <XAxis dataKey="name" stroke="rgba(148, 163, 184, 0.5)" />
            <YAxis stroke="rgba(148, 163, 184, 0.5)" />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(15, 23, 42, 0.95)",
                border: "1px solid rgba(148, 163, 184, 0.2)",
                borderRadius: "8px",
                color: "#e2e8f0",
              }}
            />
            <Bar dataKey="sessions" fill="#3b82f6" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  )
}
