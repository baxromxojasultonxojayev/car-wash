"use client"

import Dashboard from "@/components/dashboard"

export default function DashboardPage() {
  return <Dashboard />
}
