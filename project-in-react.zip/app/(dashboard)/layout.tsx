"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useTranslation } from "react-i18next"
import Navigation from "@/components/navigation"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Globe, LogOut, Menu, X } from "lucide-react"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { t, i18n } = useTranslation()
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)

  useEffect(() => {
    const storedEmail = localStorage.getItem("userEmail")
    if (!storedEmail) {
      router.push("/")
      return
    }
    setEmail(storedEmail)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("userEmail")
    router.push("/")
  }

  const changeLanguage = (lang: string) => {
    i18n.changeLanguage(lang)
  }

  return (
    <div className="min-h-screen bg-background flex">
      <div className="md:hidden fixed top-4 left-4 z-50">
        <button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="p-2 bg-card border border-border/30 rounded-lg hover:bg-card/80 transition-colors"
        >
          {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      <div
        className={`fixed md:static inset-y-0 left-0 w-64 bg-sidebar border-r border-sidebar-border/20 z-40 h-screen transition-transform duration-300 ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        }`}
      >
        <Navigation onLogout={handleLogout} />
      </div>

      <div className="flex-1 flex flex-col min-h-screen">
        <div className="bg-card border-b border-border/20 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground">{t("dashboard")}</h2>
          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-2 hover:bg-card/50 rounded-lg transition-colors" title="Change language">
                  <Globe size={20} className="text-muted-foreground hover:text-foreground transition-colors" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => changeLanguage("uz")}>Ўзбек (UZ)</DropdownMenuItem>
                <DropdownMenuItem onClick={() => changeLanguage("ru")}>Русский (RU)</DropdownMenuItem>
                <DropdownMenuItem onClick={() => changeLanguage("en")}>English (EN)</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <span className="text-sm text-muted-foreground">{email || t("admin")}</span>
            <button onClick={handleLogout} className="p-2 hover:bg-hover rounded-lg transition-colors" title="Logout">
              <LogOut size={20} className="text-muted-foreground hover:text-foreground transition-colors" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto">
          <div className="p-6">{children}</div>
        </div>
      </div>

      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black/50 md:hidden z-30" onClick={() => setIsSidebarOpen(false)} />
      )}
    </div>
  )
}
