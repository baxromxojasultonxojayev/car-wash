"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Edit2, Trash2, Search, AlertCircle, CheckCircle, Pause, Zap } from "lucide-react"
import KioskForm from "@/components/kiosks/kiosk-form"

type KioskStatus = "free" | "payment" | "active" | "pause" | "finish" | "error" | "closed"

interface Kiosk {
  id: string
  name: string
  status: KioskStatus
  isActive: boolean
  controllerMacAddress: string
  companyId: string
  branchOfficeId: string
  patternId?: string
  createdAt: string
}

export default function KiosksPage() {
  const [kiosks, setKiosks] = useState<Kiosk[]>([
    {
      id: "1",
      name: "Kiosk Premium 1",
      status: "active",
      isActive: true,
      controllerMacAddress: "00:1A:2B:3C:4D:5E",
      companyId: "1",
      branchOfficeId: "b1",
      createdAt: "2024-01-15",
    },
    {
      id: "2",
      name: "Kiosk Standard 2",
      status: "payment",
      isActive: true,
      controllerMacAddress: "00:1A:2B:3C:4D:5F",
      companyId: "1",
      branchOfficeId: "b1",
      createdAt: "2024-01-20",
    },
    {
      id: "3",
      name: "Kiosk Standard 3",
      status: "free",
      isActive: true,
      controllerMacAddress: "00:1A:2B:3C:4D:60",
      companyId: "1",
      branchOfficeId: "b2",
      createdAt: "2024-02-01",
    },
    {
      id: "4",
      name: "Kiosk Error",
      status: "error",
      isActive: false,
      controllerMacAddress: "00:1A:2B:3C:4D:61",
      companyId: "2",
      branchOfficeId: "b3",
      createdAt: "2024-02-05",
    },
  ])

  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<KioskStatus | "all">("all")
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingKiosk, setEditingKiosk] = useState<Kiosk | null>(null)

  const statusColors: Record<KioskStatus, { bg: string; text: string; icon: React.ReactNode }> = {
    free: {
      bg: "bg-green-500/10",
      text: "text-green-500",
      icon: <CheckCircle size={16} />,
    },
    payment: {
      bg: "bg-blue-500/10",
      text: "text-blue-500",
      icon: <Zap size={16} />,
    },
    active: {
      bg: "bg-cyan-500/10",
      text: "text-cyan-500",
      icon: <Zap size={16} />,
    },
    pause: {
      bg: "bg-yellow-500/10",
      text: "text-yellow-500",
      icon: <Pause size={16} />,
    },
    finish: {
      bg: "bg-purple-500/10",
      text: "text-purple-500",
      icon: <CheckCircle size={16} />,
    },
    error: {
      bg: "bg-red-500/10",
      text: "text-red-500",
      icon: <AlertCircle size={16} />,
    },
    closed: {
      bg: "bg-gray-500/10",
      text: "text-gray-500",
      icon: <AlertCircle size={16} />,
    },
  }

  const statusLabels: Record<KioskStatus, string> = {
    free: "Bo'sh",
    payment: "To'lov jarayoni",
    active: "Faol",
    pause: "To'xtatilgan",
    finish: "Tugallangan",
    error: "Xato",
    closed: "Yopilgan",
  }

  const filteredKiosks = kiosks.filter((kiosk) => {
    const matchesSearch =
      kiosk.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      kiosk.controllerMacAddress.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || kiosk.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleAddKiosk = (formData: Omit<Kiosk, "id" | "createdAt">) => {
    const newKiosk: Kiosk = {
      ...formData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString().split("T")[0],
    }
    setKiosks([...kiosks, newKiosk])
    setIsFormOpen(false)
  }

  const handleUpdateKiosk = (formData: Omit<Kiosk, "id" | "createdAt">) => {
    if (!editingKiosk) return
    const updatedKiosks = kiosks.map((kiosk) => (kiosk.id === editingKiosk.id ? { ...kiosk, ...formData } : kiosk))
    setKiosks(updatedKiosks)
    setEditingKiosk(null)
    setIsFormOpen(false)
  }

  const handleDeleteKiosk = (id: string) => {
    if (confirm("Kioskni o'chirmoqchimisiz?")) {
      setKiosks(kiosks.filter((kiosk) => kiosk.id !== id))
    }
  }

  const handleEditKiosk = (kiosk: Kiosk) => {
    setEditingKiosk(kiosk)
    setIsFormOpen(true)
  }

  const statusCounts = {
    all: kiosks.length,
    active: kiosks.filter((k) => k.status === "active").length,
    error: kiosks.filter((k) => k.status === "error").length,
    free: kiosks.filter((k) => k.status === "free").length,
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Kiosklar</h1>
          <p className="text-muted-foreground mt-1">Jami {kiosks.length} ta kiosk</p>
        </div>
        <Button
          onClick={() => {
            setEditingKiosk(null)
            setIsFormOpen(true)
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
        >
          <Plus size={20} />
          Yangi Kiosk
        </Button>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border border-border/20 p-4">
          <p className="text-muted-foreground text-sm mb-1">Jami</p>
          <p className="text-2xl font-bold text-foreground">{statusCounts.all}</p>
        </Card>
        <Card className="bg-card border border-border/20 p-4">
          <p className="text-muted-foreground text-sm mb-1">Faol</p>
          <p className="text-2xl font-bold text-cyan-500">{statusCounts.active}</p>
        </Card>
        <Card className="bg-card border border-border/20 p-4">
          <p className="text-muted-foreground text-sm mb-1">Bo\'sh</p>
          <p className="text-2xl font-bold text-green-500">{statusCounts.free}</p>
        </Card>
        <Card className="bg-card border border-border/20 p-4">
          <p className="text-muted-foreground text-sm mb-1">Xato</p>
          <p className="text-2xl font-bold text-red-500">{statusCounts.error}</p>
        </Card>
      </div>

      {/* Search and Filter */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card border border-border/20 p-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
            <Input
              placeholder="Nomi yoki MAC address bo'yicha izlash..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-input text-foreground border-border/30"
            />
          </div>
        </Card>

        <Card className="bg-card border border-border/20 p-4">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as KioskStatus | "all")}
            className="w-full px-3 py-2 bg-input text-foreground border border-border/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">Barcha statuslar</option>
            <option value="free">Bo\'sh</option>
            <option value="payment">To'lov jarayoni</option>
            <option value="active">Faol</option>
            <option value="pause">To'xtatilgan</option>
            <option value="finish">Tugallangan</option>
            <option value="error">Xato</option>
            <option value="closed">Yopilgan</option>
          </select>
        </Card>
      </div>

      {/* Kiosk Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-card border border-border/20 max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                {editingKiosk ? "Kioskni tahrir qilish" : "Yangi kiosk"}
              </h2>
              <KioskForm
                kiosk={editingKiosk}
                onSubmit={editingKiosk ? handleUpdateKiosk : handleAddKiosk}
                onCancel={() => {
                  setIsFormOpen(false)
                  setEditingKiosk(null)
                }}
              />
            </div>
          </Card>
        </div>
      )}

      {/* Kiosks Table */}
      <Card className="bg-card border border-border/20 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-border/20 bg-sidebar/20">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Nomi</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Status</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">MAC Address</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Aktiv</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Sana</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-foreground">Amallar</th>
              </tr>
            </thead>
            <tbody>
              {filteredKiosks.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">
                    Kiosk topilmadi
                  </td>
                </tr>
              ) : (
                filteredKiosks.map((kiosk) => {
                  const statusStyle = statusColors[kiosk.status]
                  return (
                    <tr key={kiosk.id} className="border-b border-border/20 hover:bg-sidebar/10 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-foreground">{kiosk.name}</td>
                      <td className="px-6 py-4 text-sm">
                        <div
                          className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${statusStyle.bg} ${statusStyle.text}`}
                        >
                          {statusStyle.icon}
                          {statusLabels[kiosk.status]}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-muted-foreground font-mono">
                        {kiosk.controllerMacAddress}
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <span
                          className={`px-2 py-1 rounded text-xs font-medium ${
                            kiosk.isActive ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                          }`}
                        >
                          {kiosk.isActive ? "Ha" : "Yo'q"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-muted-foreground">{kiosk.createdAt}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleEditKiosk(kiosk)}
                            className="p-2 hover:bg-blue-500/10 text-blue-500 rounded-lg transition-colors"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => handleDeleteKiosk(kiosk.id)}
                            className="p-2 hover:bg-red-500/10 text-red-500 rounded-lg transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
