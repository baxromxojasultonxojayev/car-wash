"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Edit2, Trash2, Search, X } from "lucide-react"
import UserForm from "@/components/users/user-form"

interface User {
  id: string
  email: string
  firstName: string
  lastName: string
  phoneNumber?: string
  role: "SuperAdmin" | "Admin" | "User"
  createdAt: string
}

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([
    {
      id: "1",
      email: "admin@carwash.com",
      firstName: "Admin",
      lastName: "User",
      phoneNumber: "+998901234567",
      role: "SuperAdmin",
      createdAt: "2024-01-15",
    },
    {
      id: "2",
      email: "manager@carwash.com",
      firstName: "Manager",
      lastName: "One",
      phoneNumber: "+998902345678",
      role: "Admin",
      createdAt: "2024-01-20",
    },
  ])

  const [searchTerm, setSearchTerm] = useState("")
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)

  const filteredUsers = users.filter(
    (user) =>
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.lastName.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAddUser = (formData: Omit<User, "id" | "createdAt">) => {
    const newUser: User = {
      ...formData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString().split("T")[0],
    }
    setUsers([...users, newUser])
    setIsFormOpen(false)
  }

  const handleUpdateUser = (formData: Omit<User, "id" | "createdAt">) => {
    if (!editingUser) return
    const updatedUsers = users.map((user) => (user.id === editingUser.id ? { ...user, ...formData } : user))
    setUsers(updatedUsers)
    setEditingUser(null)
    setIsFormOpen(false)
  }

  const handleDeleteUser = (id: string) => {
    if (confirm("Foydalanuvchini o'chirmoqchimisiz?")) {
      setUsers(users.filter((user) => user.id !== id))
    }
  }

  const handleEditUser = (user: User) => {
    setEditingUser(user)
    setIsFormOpen(true)
  }

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      SuperAdmin: "bg-red-500/10 text-red-500",
      Admin: "bg-blue-500/10 text-blue-500",
      User: "bg-green-500/10 text-green-500",
    }
    return colors[role] || "bg-gray-500/10 text-gray-500"
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Foydalanuvchilar</h1>
          <p className="text-muted-foreground mt-1">Jami {users.length} ta foydalanuvchi</p>
        </div>
        <Button
          onClick={() => {
            setEditingUser(null)
            setIsFormOpen(true)
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
        >
          <Plus size={20} />
          Yangi Foydalanuvchi
        </Button>
      </div>

      {/* Search */}
      <Card className="bg-card border border-border/20 p-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
          <Input
            placeholder="Email, ism yoki familya bo'yicha izlash..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-input text-foreground border-border/30"
          />
        </div>
      </Card>

      {/* User Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-card border border-border/20">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-foreground">
                  {editingUser ? "Foydalanuvchini tahrir qilish" : "Yangi foydalanuvchi"}
                </h2>
                <button
                  onClick={() => {
                    setIsFormOpen(false)
                    setEditingUser(null)
                  }}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X size={24} />
                </button>
              </div>
              <UserForm
                user={editingUser}
                onSubmit={editingUser ? handleUpdateUser : handleAddUser}
                onCancel={() => {
                  setIsFormOpen(false)
                  setEditingUser(null)
                }}
              />
            </div>
          </Card>
        </div>
      )}

      {/* Users Table */}
      <Card className="bg-card border border-border/20 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-border/20 bg-sidebar/20">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Email</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Ism-Familya</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Telefon</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Rol</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Sana</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-foreground">Amallar</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">
                    Foydalanuvchi topilmadi
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b border-border/20 hover:bg-sidebar/10 transition-colors">
                    <td className="px-6 py-4 text-sm text-foreground">{user.email}</td>
                    <td className="px-6 py-4 text-sm text-foreground">
                      {user.firstName} {user.lastName}
                    </td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{user.phoneNumber || "-"}</td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getRoleColor(user.role)}`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{user.createdAt}</td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleEditUser(user)}
                          className="p-2 hover:bg-blue-500/10 text-blue-500 rounded-lg transition-colors"
                          title="Tahrir"
                        >
                          <Edit2 size={18} />
                        </button>
                        <button
                          onClick={() => handleDeleteUser(user.id)}
                          className="p-2 hover:bg-red-500/10 text-red-500 rounded-lg transition-colors"
                          title="O'chirish"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
