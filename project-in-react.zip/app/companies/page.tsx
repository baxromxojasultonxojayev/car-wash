"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Edit2, Trash2, Search, MapPin } from "lucide-react"
import CompanyForm from "@/components/companies/company-form"

interface BranchOffice {
  id: string
  name: string
  location: string
}

interface Company {
  id: string
  name: string
  description?: string
  ownerId?: string
  branches: BranchOffice[]
  createdAt: string
}

export default function CompaniesPage() {
  const [companies, setCompanies] = useState<Company[]>([
    {
      id: "1",
      name: "CarWash Premium",
      description: "Tashkent shahrida eng yaxshi carwash xizmati",
      ownerId: "1",
      branches: [
        { id: "b1", name: "Mirzo Ulugbek", location: "Mirzo Ulugbek ko'chasi" },
        { id: "b2", name: "Yunus-Obod", location: "Yunus-Obod ko'chasi" },
      ],
      createdAt: "2024-01-01",
    },
    {
      id: "2",
      name: "Quick Clean",
      description: "Tezkor va sifatli xizmat",
      ownerId: "2",
      branches: [{ id: "b3", name: "Fergona", location: "Fergona shahar" }],
      createdAt: "2024-02-01",
    },
  ])

  const [searchTerm, setSearchTerm] = useState("")
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingCompany, setEditingCompany] = useState<Company | null>(null)
  const [expandedCompany, setExpandedCompany] = useState<string | null>(null)

  const filteredCompanies = companies.filter(
    (company) =>
      company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      company.description?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAddCompany = (formData: Omit<Company, "id" | "createdAt">) => {
    const newCompany: Company = {
      ...formData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString().split("T")[0],
    }
    setCompanies([...companies, newCompany])
    setIsFormOpen(false)
  }

  const handleUpdateCompany = (formData: Omit<Company, "id" | "createdAt">) => {
    if (!editingCompany) return
    const updatedCompanies = companies.map((company) =>
      company.id === editingCompany.id ? { ...company, ...formData } : company,
    )
    setCompanies(updatedCompanies)
    setEditingCompany(null)
    setIsFormOpen(false)
  }

  const handleDeleteCompany = (id: string) => {
    if (confirm("Kompaniyani o'chirmoqchimisiz?")) {
      setCompanies(companies.filter((company) => company.id !== id))
    }
  }

  const handleEditCompany = (company: Company) => {
    setEditingCompany(company)
    setIsFormOpen(true)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Kompaniyalar</h1>
          <p className="text-muted-foreground mt-1">Jami {companies.length} ta kompaniya</p>
        </div>
        <Button
          onClick={() => {
            setEditingCompany(null)
            setIsFormOpen(true)
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
        >
          <Plus size={20} />
          Yangi Kompaniya
        </Button>
      </div>

      {/* Search */}
      <Card className="bg-card border border-border/20 p-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
          <Input
            placeholder="Kompaniya nomi yoki tavsifi bo'yicha izlash..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-input text-foreground border-border/30"
          />
        </div>
      </Card>

      {/* Company Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-2xl bg-card border border-border/20 max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                {editingCompany ? "Kompaniyani tahrir qilish" : "Yangi kompaniya"}
              </h2>
              <CompanyForm
                company={editingCompany}
                onSubmit={editingCompany ? handleUpdateCompany : handleAddCompany}
                onCancel={() => {
                  setIsFormOpen(false)
                  setEditingCompany(null)
                }}
              />
            </div>
          </Card>
        </div>
      )}

      {/* Companies Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCompanies.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <p className="text-muted-foreground">Kompaniya topilmadi</p>
          </div>
        ) : (
          filteredCompanies.map((company) => (
            <Card
              key={company.id}
              className="bg-card border border-border/20 overflow-hidden hover:border-blue-500/30 transition-colors"
            >
              <div className="p-6">
                {/* Company Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-foreground">{company.name}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{company.description || "Tavsif yo'q"}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEditCompany(company)}
                      className="p-2 hover:bg-blue-500/10 text-blue-500 rounded-lg transition-colors"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button
                      onClick={() => handleDeleteCompany(company.id)}
                      className="p-2 hover:bg-red-500/10 text-red-500 rounded-lg transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>

                {/* Meta Info */}
                <div className="text-xs text-muted-foreground mb-4 pb-4 border-b border-border/20">
                  Yaratilgan: {company.createdAt}
                </div>

                {/* Branches */}
                <div>
                  <button
                    onClick={() => setExpandedCompany(expandedCompany === company.id ? null : company.id)}
                    className="w-full text-left flex items-center gap-2 text-sm font-medium text-foreground hover:text-blue-500 transition-colors mb-2"
                  >
                    <MapPin size={16} />
                    {company.branches.length} ta filial
                  </button>

                  {expandedCompany === company.id && (
                    <div className="space-y-2 mt-3 pl-6 border-l border-border/20">
                      {company.branches.map((branch) => (
                        <div key={branch.id} className="text-sm">
                          <p className="font-medium text-foreground">{branch.name}</p>
                          <p className="text-xs text-muted-foreground">{branch.location}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
