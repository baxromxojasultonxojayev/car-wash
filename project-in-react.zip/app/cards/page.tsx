"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Edit2, Trash2, Search, CreditCard, Lock, Unlock } from "lucide-react"
import CardForm from "@/components/cards/card-form"

interface RFIDCard {
  id: string
  cardNumber: string
  balance: number
  isActive: boolean
  createdAt: string
  companyId?: string
  ownerId?: string
}

export default function CardsPage() {
  const [cards, setCards] = useState<RFIDCard[]>([
    {
      id: "1",
      cardNumber: "1234567890AB",
      balance: 50000,
      isActive: true,
      createdAt: "2024-01-15",
      companyId: "1",
      ownerId: "1",
    },
    {
      id: "2",
      cardNumber: "1234567890AC",
      balance: 25000,
      isActive: true,
      createdAt: "2024-01-20",
      companyId: "1",
      ownerId: "2",
    },
    {
      id: "3",
      cardNumber: "1234567890AD",
      balance: 0,
      isActive: false,
      createdAt: "2024-02-01",
      companyId: "1",
    },
    {
      id: "4",
      cardNumber: "1234567890AE",
      balance: 75000,
      isActive: true,
      createdAt: "2024-02-05",
      companyId: "2",
    },
  ])

  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all")
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingCard, setEditingCard] = useState<RFIDCard | null>(null)

  const filteredCards = cards.filter((card) => {
    const matchesSearch = card.cardNumber.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus =
      statusFilter === "all" ||
      (statusFilter === "active" && card.isActive) ||
      (statusFilter === "inactive" && !card.isActive)
    return matchesSearch && matchesStatus
  })

  const handleAddCard = (formData: Omit<RFIDCard, "id" | "createdAt">) => {
    const newCard: RFIDCard = {
      ...formData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString().split("T")[0],
    }
    setCards([...cards, newCard])
    setIsFormOpen(false)
  }

  const handleUpdateCard = (formData: Omit<RFIDCard, "id" | "createdAt">) => {
    if (!editingCard) return
    const updatedCards = cards.map((card) => (card.id === editingCard.id ? { ...card, ...formData } : card))
    setCards(updatedCards)
    setEditingCard(null)
    setIsFormOpen(false)
  }

  const handleDeleteCard = (id: string) => {
    if (confirm("Kartani o'chirmoqchimisiz?")) {
      setCards(cards.filter((card) => card.id !== id))
    }
  }

  const handleEditCard = (card: RFIDCard) => {
    setEditingCard(card)
    setIsFormOpen(true)
  }

  const handleToggleStatus = (id: string) => {
    const updatedCards = cards.map((card) => (card.id === id ? { ...card, isActive: !card.isActive } : card))
    setCards(updatedCards)
  }

  const stats = {
    total: cards.length,
    active: cards.filter((c) => c.isActive).length,
    inactive: cards.filter((c) => !c.isActive).length,
    totalBalance: cards.reduce((sum, c) => sum + c.balance, 0),
  }

  const formatBalance = (amount: number) => {
    return new Intl.NumberFormat("uz-UZ", {
      style: "currency",
      currency: "UZS",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">RFID Kartalar</h1>
          <p className="text-muted-foreground mt-1">Jami {cards.length} ta karta</p>
        </div>
        <Button
          onClick={() => {
            setEditingCard(null)
            setIsFormOpen(true)
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
        >
          <Plus size={20} />
          Yangi Karta
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border border-border/20 p-4">
          <p className="text-muted-foreground text-sm mb-1">Jami Kartalar</p>
          <p className="text-2xl font-bold text-foreground">{stats.total}</p>
        </Card>
        <Card className="bg-card border border-border/20 p-4">
          <p className="text-muted-foreground text-sm mb-1">Faol</p>
          <p className="text-2xl font-bold text-green-500">{stats.active}</p>
        </Card>
        <Card className="bg-card border border-border/20 p-4">
          <p className="text-muted-foreground text-sm mb-1">Nofaol</p>
          <p className="text-2xl font-bold text-red-500">{stats.inactive}</p>
        </Card>
        <Card className="bg-card border border-border/20 p-4">
          <p className="text-muted-foreground text-sm mb-1">Umumiy Balans</p>
          <p className="text-xl font-bold text-cyan-500 truncate">{formatBalance(stats.totalBalance)}</p>
        </Card>
      </div>

      {/* Search and Filter */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card border border-border/20 p-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
            <Input
              placeholder="Karta raqami bo'yicha izlash..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-input text-foreground border-border/30"
            />
          </div>
        </Card>

        <Card className="bg-card border border-border/20 p-4">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as "all" | "active" | "inactive")}
            className="w-full px-3 py-2 bg-input text-foreground border border-border/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">Barcha kartalar</option>
            <option value="active">Faol kartalar</option>
            <option value="inactive">Nofaol kartalar</option>
          </select>
        </Card>
      </div>

      {/* Card Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-card border border-border/20">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                {editingCard ? "Kartani tahrir qilish" : "Yangi karta"}
              </h2>
              <CardForm
                card={editingCard}
                onSubmit={editingCard ? handleUpdateCard : handleAddCard}
                onCancel={() => {
                  setIsFormOpen(false)
                  setEditingCard(null)
                }}
              />
            </div>
          </Card>
        </div>
      )}

      {/* Cards Table */}
      <Card className="bg-card border border-border/20 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-border/20 bg-sidebar/20">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Karta Raqami</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Balans</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Status</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Sana</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-foreground">Amallar</th>
              </tr>
            </thead>
            <tbody>
              {filteredCards.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-muted-foreground">
                    Karta topilmadi
                  </td>
                </tr>
              ) : (
                filteredCards.map((card) => (
                  <tr key={card.id} className="border-b border-border/20 hover:bg-sidebar/10 transition-colors">
                    <td className="px-6 py-4 text-sm font-mono font-medium text-foreground">
                      <div className="flex items-center gap-2">
                        <CreditCard size={16} className="text-blue-500" />
                        {card.cardNumber}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm font-bold text-cyan-500">{formatBalance(card.balance)}</td>
                    <td className="px-6 py-4 text-sm">
                      <span
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${
                          card.isActive ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                        }`}
                      >
                        {card.isActive ? (
                          <>
                            <Unlock size={12} />
                            Faol
                          </>
                        ) : (
                          <>
                            <Lock size={12} />
                            Nofaol
                          </>
                        )}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{card.createdAt}</td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleToggleStatus(card.id)}
                          className={`p-2 rounded-lg transition-colors ${
                            card.isActive ? "hover:bg-red-500/10 text-red-500" : "hover:bg-green-500/10 text-green-500"
                          }`}
                          title={card.isActive ? "Bloklash" : "Aktivlashtirish"}
                        >
                          {card.isActive ? <Lock size={18} /> : <Unlock size={18} />}
                        </button>
                        <button
                          onClick={() => handleEditCard(card)}
                          className="p-2 hover:bg-blue-500/10 text-blue-500 rounded-lg transition-colors"
                        >
                          <Edit2 size={18} />
                        </button>
                        <button
                          onClick={() => handleDeleteCard(card.id)}
                          className="p-2 hover:bg-red-500/10 text-red-500 rounded-lg transition-colors"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
