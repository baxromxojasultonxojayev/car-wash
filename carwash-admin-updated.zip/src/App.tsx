import { Navigate, useRoutes } from "react-router-dom";
import { appRoutes } from "./router/routes";
import LoginPage from "./pages/auth/login";
import RegisterPage from "./pages/auth/register";
import ForgotPasswordPage from "./pages/auth/forgot-password";

export default function App() {
  const routes = [
    { path: "/login", element: <LoginPage /> },
    { path: "/register", element: <RegisterPage /> },
    { path: "/forgot-password", element: <ForgotPasswordPage /> },
    { path: "/", element: <Navigate to="/dashboard" replace /> },
    ...appRoutes
  ];
  const element = useRoutes(routes);
  return element;
}
