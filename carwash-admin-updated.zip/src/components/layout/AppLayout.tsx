import { Layout } from "antd";
import Sidebar from "./Sidebar";
import HeaderBar from "./HeaderBar";
import { Outlet } from "react-router-dom";
import "./layout.scss";

const { Content } = Layout;

export default function AppLayout() {
  return (
    <Layout className="app-layout">
      <Sidebar />
      <Layout>
        <HeaderBar />
        <Content className="app-content">
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
}
