import { Layout, Menu } from "antd";
import {
  DashboardOutlined,
  UserOutlined,
  ClusterOutlined,
  ShopOutlined,
  CreditCardOutlined,
  ApartmentOutlined,
  HddOutlined,
  PlayCircleOutlined,
  DollarOutlined,
  PictureOutlined
} from "@ant-design/icons";
import { useTranslation } from "react-i18next";
import { useLocation, useNavigate } from "react-router-dom";

const { Sider } = Layout;

const items = [
  { key: "/dashboard", icon: <DashboardOutlined />, labelKey: "nav.dashboard" },
  { key: "/users", icon: <UserOutlined />, labelKey: "nav.users" },
  { key: "/companies", icon: <ClusterOutlined />, labelKey: "nav.companies" },
  { key: "/branches", icon: <ApartmentOutlined />, labelKey: "nav.branches" },
  { key: "/kiosks", icon: <ShopOutlined />, labelKey: "nav.kiosks" },
  { key: "/rfid-cards", icon: <CreditCardOutlined />, labelKey: "nav.rfidCards" },
  { key: "/services", icon: <HddOutlined />, labelKey: "nav.services" },
  { key: "/patterns", icon: <PlayCircleOutlined />, labelKey: "nav.patterns" },
  {
    key: "/pattern-services",
    icon: <PlayCircleOutlined />,
    labelKey: "nav.patternServices"
  },
  {
    key: "/advertisements",
    icon: <PictureOutlined />,
    labelKey: "nav.advertisements"
  },
  {
    key: "/wash-sessions",
    icon: <PlayCircleOutlined />,
    labelKey: "nav.washSessions"
  },
  { key: "/payments", icon: <DollarOutlined />, labelKey: "nav.payments" }
];

export default function Sidebar() {
  const { t } = useTranslation("common");
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <Sider width={240} className="app-sider">
      <div className="logo">{t("app.title")}</div>
      <Menu
        mode="inline"
        selectedKeys={[location.pathname]}
        items={items.map((item) => ({
          key: item.key,
          icon: item.icon,
          label: t(item.labelKey)
        }))}
        onClick={(info) => navigate(info.key)}
      />
    </Sider>
  );
}
