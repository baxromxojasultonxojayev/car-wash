import { Layout, Space, Select } from "antd";
import { useTranslation } from "react-i18next";

const { Header } = Layout;

const LANGUAGE_OPTIONS = [
  { value: "uz", label: "UZ" },
  { value: "ru", label: "RU" },
  { value: "en", label: "EN" }
];

export default function HeaderBar() {
  const { i18n } = useTranslation();

  return (
    <Header className="app-header">
      <Space style={{ width: "100%", justifyContent: "flex-end" }}>
        <Select
          value={i18n.language}
          options={LANGUAGE_OPTIONS}
          onChange={(lng) => i18n.changeLanguage(lng)}
          style={{ width: 90 }}
          size="small"
        />
      </Space>
    </Header>
  );
}
