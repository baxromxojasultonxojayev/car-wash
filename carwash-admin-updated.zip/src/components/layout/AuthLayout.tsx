import { ReactNode } from "react";
import { Layout, Typography } from "antd";
import "./auth-layout.scss";

const { Content } = Layout;
const { Title, Text } = Typography;

interface Props {
  title?: string;
  subtitle?: string;
  children: ReactNode;
}

export default function AuthLayout({ title, subtitle, children }: Props) {
  return (
    <Layout className="auth-layout">
      <Content className="auth-content">
        <div className="auth-card">
          <div className="auth-brand">
            <Title level={3} className="auth-logo">
              Car Wash Admin
            </Title>
            {title && <Title level={4}>{title}</Title>}
            {subtitle && <Text type="secondary">{subtitle}</Text>}
          </div>
          <div className="auth-form">{children}</div>
        </div>
      </Content>
    </Layout>
  );
}
