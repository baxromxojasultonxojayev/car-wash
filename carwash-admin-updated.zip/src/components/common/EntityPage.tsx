import { useEffect, useState } from "react";
import {
  Button,
  Modal,
  Form,
  Table,
  Space,
  Popconfirm,
  message,
  Card
} from "antd";
import { useTranslation } from "react-i18next";
import {
  listEntities,
  createEntity,
  updateEntity,
  deleteEntity,
  EntityName
} from "../../api/crudClient";
import { EntityForm, FieldConfig } from "./EntityForm";

interface Props<T extends { id: number | string }> {
  entity: EntityName;
  titleKey: string;
  columns: any[];
  formFields: FieldConfig[];
}

export default function EntityPage<T extends { id: number | string }>({
  entity,
  titleKey,
  columns,
  formFields
}: Props<T>) {
  const { t } = useTranslation("common");
  const [items, setItems] = useState<T[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<T | null>(null);
  const [form] = Form.useForm();

  const load = async () => {
    try {
      setLoading(true);
      const data = await listEntities<T>(entity, { page, pageSize });
      setItems(data.results);
      setTotal(data.total);
    } catch (e: any) {
      message.error(e.message || "Error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  const onCreate = () => {
    setEditing(null);
    form.resetFields();
    setOpen(true);
  };

  const onEdit = (record: T) => {
    setEditing(record);
    form.setFieldsValue(record);
    setOpen(true);
  };

  const onDelete = async (record: T) => {
    try {
      await deleteEntity(entity, record.id);
      message.success("Deleted");
      load();
    } catch (e: any) {
      message.error(e.message || "Error");
    }
  };

  const onSubmit = async () => {
    const values = await form.validateFields();
    try {
      if (editing) {
        await updateEntity(entity, editing.id, values);
        message.success("Updated");
      } else {
        await createEntity(entity, values);
        message.success("Created");
      }
      setOpen(false);
      load();
    } catch (e: any) {
      message.error(e.message || "Error");
    }
  };

  const tableColumns = [
    ...columns,
    {
      title: t("table.actions"),
      key: "actions",
      fixed: "right" as const,
      render: (_: any, record: T) => (
        <Space>
          <Button size="small" onClick={() => onEdit(record)}>
            {t("actions.edit")}
          </Button>
          <Popconfirm
            title={t("actions.delete")}
            onConfirm={() => onDelete(record)}
          >
            <Button danger size="small">
              {t("actions.delete")}
            </Button>
          </Popconfirm>
        </Space>
      )
    }
  ];

  return (
    <>
      <div className="page-header">
        <h2>{t(titleKey)}</h2>
        <Button type="primary" onClick={onCreate}>
          {t("actions.create")}
        </Button>
      </div>

      <Card className="page-card" bodyStyle={{ padding: 0 }}>
        <Table
          rowKey="id"
          loading={loading}
          dataSource={items}
          columns={tableColumns}
          pagination={{
            current: page,
            pageSize,
            total,
            onChange: (p) => setPage(p)
          }}
        />
      </Card>

      <Modal
        open={open}
        onCancel={() => setOpen(false)}
        onOk={onSubmit}
        okText={t("actions.save")}
        cancelText={t("actions.cancel")}
        destroyOnClose
      >
        <Form form={form} layout="vertical">
          <EntityForm fields={formFields} />
        </Form>
      </Modal>
    </>
  );
}
