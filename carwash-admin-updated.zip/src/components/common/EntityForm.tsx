import { Form, Input, InputNumber, Switch, Select } from "antd";

export type FieldType = "text" | "number" | "boolean" | "select";

export interface FieldConfig {
  name: string;
  label: string;
  type: FieldType;
  options?: { label: string; value: any }[];
}

interface Props {
  fields: FieldConfig[];
}

export function EntityForm({ fields }: Props) {
  return (
    <>
      {fields.map((f) => {
        const key = f.name;
        if (f.type === "text") {
          return (
            <Form.Item key={key} name={key} label={f.label} rules={[{ required: true }]}>
              <Input />
            </Form.Item>
          );
        }
        if (f.type === "number") {
          return (
            <Form.Item key={key} name={key} label={f.label} rules={[{ required: true }]}>
              <InputNumber style={{ width: "100%" }} />
            </Form.Item>
          );
        }
        if (f.type === "boolean") {
          return (
            <Form.Item
              key={key}
              name={key}
              label={f.label}
              valuePropName="checked"
            >
              <Switch />
            </Form.Item>
          );
        }
        if (f.type === "select") {
          return (
            <Form.Item key={key} name={key} label={f.label}>
              <Select options={f.options} />
            </Form.Item>
          );
        }
        return null;
      })}
    </>
  );
}
