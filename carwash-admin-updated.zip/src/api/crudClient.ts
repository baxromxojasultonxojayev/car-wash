import { apiClient } from "./client";

export type EntityName =
  | "users"
  | "companies"
  | "branches"
  | "kiosks"
  | "rfid-cards"
  | "services"
  | "patterns"
  | "pattern-services"
  | "advertisements"
  | "wash-sessions"
  | "payments";

export interface ListParams {
  page?: number;
  pageSize?: number;
}

export async function listEntities<T>(entity: EntityName, params?: ListParams) {
  const res = await apiClient.get<{ results: T[]; total: number }>(
    `/${entity}/`,
    { params }
  );
  return res.data;
}

export async function createEntity<T>(
  entity: EntityName,
  payload: Partial<T>
) {
  const res = await apiClient.post<T>(`/${entity}/`, payload);
  return res.data;
}

export async function updateEntity<T>(
  entity: EntityName,
  id: number | string,
  payload: Partial<T>
) {
  const res = await apiClient.put<T>(`/${entity}/${id}/`, payload);
  return res.data;
}

export async function deleteEntity(
  entity: EntityName,
  id: number | string
): Promise<void> {
  await apiClient.delete(`/${entity}/${id}/`);
}
