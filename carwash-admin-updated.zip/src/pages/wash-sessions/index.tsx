import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { useTranslation } from "react-i18next";

interface WashSession {
  id: number;
  kiosk_name?: string;
  created_at?: string;
  started_at?: string;
  finished_at?: string;
  duration_sec?: number;
  total_paid?: number;
  status?: string;
}

export default function WashSessionsPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<WashSession> = [
    { title: t("washSession.kiosk"), dataIndex: "kiosk_name" },
    { title: t("washSession.createdAt"), dataIndex: "created_at" },
    { title: t("washSession.startedAt"), dataIndex: "started_at" },
    { title: t("washSession.finishedAt"), dataIndex: "finished_at" },
    { title: t("washSession.duration"), dataIndex: "duration_sec" },
    { title: t("washSession.totalPaid"), dataIndex: "total_paid" },
    { title: t("washSession.status"), dataIndex: "status" }
  ];

  return (
    <EntityPage<WashSession>
      entity="wash-sessions"
      titleKey="nav.washSessions"
      columns={columns}
      formFields={[
        { name: "kiosk_name", label: t("washSession.kiosk"), type: "text" },
        { name: "created_at", label: t("washSession.createdAt"), type: "text" },
        { name: "started_at", label: t("washSession.startedAt"), type: "text" },
        { name: "finished_at", label: t("washSession.finishedAt"), type: "text" },
        { name: "duration_sec", label: t("washSession.duration"), type: "number" },
        { name: "total_paid", label: t("washSession.totalPaid"), type: "number" },
        { name: "status", label: t("washSession.status"), type: "text" }
      ]}
    />
  );
}
