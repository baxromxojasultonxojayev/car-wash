import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { useTranslation } from "react-i18next";

interface Company {
  id: number;
  name: string;
  description?: string;
  owner?: string;
}

export default function CompaniesPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<Company> = [
    { title: t("company.name"), dataIndex: "name" },
    { title: t("company.description"), dataIndex: "description" },
    { title: t("company.owner"), dataIndex: "owner" }
  ];

  return (
    <EntityPage<Company>
      entity="companies"
      titleKey="nav.companies"
      columns={columns}
      formFields={[
        { name: "name", label: t("company.name"), type: "text" },
        { name: "description", label: t("company.description"), type: "text" },
        { name: "owner", label: t("company.owner"), type: "text" }
      ]}
    />
  );
}
