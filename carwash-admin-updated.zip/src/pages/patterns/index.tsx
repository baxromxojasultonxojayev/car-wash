import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { useTranslation } from "react-i18next";

interface Pattern {
  id: number;
  name: string;
  description?: string;
  company_name?: string;
}

export default function PatternsPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<Pattern> = [
    { title: t("pattern.name"), dataIndex: "name" },
    { title: t("pattern.description"), dataIndex: "description" },
    { title: t("pattern.company"), dataIndex: "company_name" }
  ];

  return (
    <EntityPage<Pattern>
      entity="patterns"
      titleKey="nav.patterns"
      columns={columns}
      formFields={[
        { name: "name", label: t("pattern.name"), type: "text" },
        { name: "description", label: t("pattern.description"), type: "text" },
        { name: "company_name", label: t("pattern.company"), type: "text" }
      ]}
    />
  );
}
