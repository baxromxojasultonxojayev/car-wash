import { Button, Form, Input, Typography } from "antd";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import AuthLayout from "../../../components/layout/AuthLayout";

const { Text } = Typography;

export default function ForgotPasswordPage() {
  const { t } = useTranslation("common");

  const onFinish = () => {
    // TODO: integrate real forgot password API
  };

  return (
    <AuthLayout
      title={t("auth.forgot.title")}
      subtitle={t("auth.forgot.subtitle")}
    >
      <Form layout="vertical" onFinish={onFinish}>
        <Form.Item
          label={t("auth.email")}
          name="email"
          rules={[{ required: true, message: t("auth.required") }]}
        >
          <Input placeholder={t("auth.email.placeholder")} />
        </Form.Item>
        <Form.Item style={{ marginTop: 8 }}>
          <Button type="primary" htmlType="submit" block>
            {t("auth.forgot.button")}
          </Button>
        </Form.Item>
        <div className="auth-footer-links" style={{ marginTop: 8 }}>
          <Text type="secondary">
            {t("auth.rememberPassword")}{" "}
            <Link to="/login">{t("auth.login.link")}</Link>
          </Text>
        </div>
      </Form>
    </AuthLayout>
  );
}
