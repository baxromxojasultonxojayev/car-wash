import { Button, Form, Input, Typography } from "antd";
import { Link, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import AuthLayout from "../../../components/layout/AuthLayout";

const { Text } = Typography;

export default function LoginPage() {
  const { t } = useTranslation("common");
  const navigate = useNavigate();

  const onFinish = () => {
    // TODO: integrate real auth API
    navigate("/dashboard");
  };

  return (
    <AuthLayout
      title={t("auth.login.title")}
      subtitle={t("auth.login.subtitle")}
    >
      <Form layout="vertical" onFinish={onFinish}>
        <Form.Item
          label={t("auth.email")}
          name="email"
          rules={[{ required: true, message: t("auth.required") }]}
        >
          <Input placeholder={t("auth.email.placeholder")} />
        </Form.Item>
        <Form.Item
          label={t("auth.password")}
          name="password"
          rules={[{ required: true, message: t("auth.required") }]}
        >
          <Input.Password placeholder={t("auth.password.placeholder")} />
        </Form.Item>
        <div className="auth-footer-links">
          <Link to="/forgot-password">{t("auth.forgotPassword")}</Link>
        </div>
        <Form.Item style={{ marginTop: 16 }}>
          <Button type="primary" htmlType="submit" block>
            {t("auth.login.button")}
          </Button>
        </Form.Item>
        <Text type="secondary">
          {t("auth.noAccount")}{" "}
          <Link to="/register">{t("auth.register.link")}</Link>
        </Text>
      </Form>
    </AuthLayout>
  );
}
