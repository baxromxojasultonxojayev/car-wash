import { Button, Form, Input, Typography } from "antd";
import { Link, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import AuthLayout from "../../../components/layout/AuthLayout";

const { Text } = Typography;

export default function RegisterPage() {
  const { t } = useTranslation("common");
  const navigate = useNavigate();

  const onFinish = () => {
    // TODO: integrate real register API
    navigate("/dashboard");
  };

  return (
    <AuthLayout
      title={t("auth.register.title")}
      subtitle={t("auth.register.subtitle")}
    >
      <Form layout="vertical" onFinish={onFinish}>
        <Form.Item
          label={t("user.firstName")}
          name="first_name"
          rules={[{ required: true, message: t("auth.required") }]}
        >
          <Input placeholder={t("user.firstName")} />
        </Form.Item>
        <Form.Item
          label={t("user.lastName")}
          name="last_name"
          rules={[{ required: true, message: t("auth.required") }]}
        >
          <Input placeholder={t("user.lastName")} />
        </Form.Item>
        <Form.Item
          label={t("auth.email")}
          name="email"
          rules={[{ required: true, message: t("auth.required") }]}
        >
          <Input placeholder={t("auth.email.placeholder")} />
        </Form.Item>
        <Form.Item
          label={t("auth.password")}
          name="password"
          rules={[{ required: true, message: t("auth.required") }]}
        >
          <Input.Password placeholder={t("auth.password.placeholder")} />
        </Form.Item>
        <Form.Item
          label={t("auth.passwordConfirm")}
          name="password_confirm"
          dependencies={["password"]}
          rules={[{ required: true, message: t("auth.required") }]}
        >
          <Input.Password placeholder={t("auth.passwordConfirm.placeholder")} />
        </Form.Item>
        <Form.Item style={{ marginTop: 8 }}>
          <Button type="primary" htmlType="submit" block>
            {t("auth.register.button")}
          </Button>
        </Form.Item>
        <Text type="secondary">
          {t("auth.haveAccount")}{" "}
          <Link to="/login">{t("auth.login.link")}</Link>
        </Text>
      </Form>
    </AuthLayout>
  );
}
