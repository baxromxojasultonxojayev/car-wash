import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { Tag } from "antd";
import { useTranslation } from "react-i18next";

interface RfidCard {
  id: number;
  card_number: string;
  balance: number;
  is_active: boolean;
  company_name?: string;
  owner_name?: string;
}

export default function RfidCardsPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<RfidCard> = [
    { title: t("rfid.cardNumber"), dataIndex: "card_number" },
    { title: t("rfid.balance"), dataIndex: "balance" },
    {
      title: t("rfid.isActive"),
      dataIndex: "is_active",
      render: (v: boolean) => (v ? <Tag color="green">ON</Tag> : <Tag color="red">OFF</Tag>)
    },
    { title: t("rfid.company"), dataIndex: "company_name" },
    { title: t("rfid.owner"), dataIndex: "owner_name" }
  ];

  return (
    <EntityPage<RfidCard>
      entity="rfid-cards"
      titleKey="nav.rfidCards"
      columns={columns}
      formFields={[
        { name: "card_number", label: t("rfid.cardNumber"), type: "text" },
        { name: "balance", label: t("rfid.balance"), type: "number" },
        { name: "is_active", label: t("rfid.isActive"), type: "boolean" },
        { name: "company_name", label: t("rfid.company"), type: "text" },
        { name: "owner_name", label: t("rfid.owner"), type: "text" }
      ]}
    />
  );
}
