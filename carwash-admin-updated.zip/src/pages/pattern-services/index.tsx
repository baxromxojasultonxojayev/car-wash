import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { Tag } from "antd";
import { useTranslation } from "react-i18next";

interface PatternService {
  id: number;
  service_name: string;
  is_active: boolean;
  relays?: string;
  price_per_second?: number;
  pump1_power?: number;
  pump2_power?: number;
  pump3_power?: number;
  pump4_power?: number;
  motor_frequency?: number;
  motor_flag?: boolean;
}

export default function PatternServicesPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<PatternService> = [
    { title: t("patternService.serviceName"), dataIndex: "service_name" },
    {
      title: t("patternService.isActive"),
      dataIndex: "is_active",
      render: (v: boolean) => (v ? <Tag color="green">ON</Tag> : <Tag color="red">OFF</Tag>)
    },
    { title: t("patternService.relays"), dataIndex: "relays" },
    { title: t("patternService.pricePerSecond"), dataIndex: "price_per_second" }
  ];

  return (
    <EntityPage<PatternService>
      entity="pattern-services"
      titleKey="nav.patternServices"
      columns={columns}
      formFields={[
        {
          name: "service_name",
          label: t("patternService.serviceName"),
          type: "text"
        },
        {
          name: "is_active",
          label: t("patternService.isActive"),
          type: "boolean"
        },
        { name: "relays", label: t("patternService.relays"), type: "text" },
        {
          name: "price_per_second",
          label: t("patternService.pricePerSecond"),
          type: "number"
        },
        {
          name: "pump1_power",
          label: t("patternService.pump1Power"),
          type: "number"
        },
        {
          name: "pump2_power",
          label: t("patternService.pump2Power"),
          type: "number"
        },
        {
          name: "pump3_power",
          label: t("patternService.pump3Power"),
          type: "number"
        },
        {
          name: "pump4_power",
          label: t("patternService.pump4Power"),
          type: "number"
        },
        {
          name: "motor_frequency",
          label: t("patternService.motorFrequency"),
          type: "number"
        },
        {
          name: "motor_flag",
          label: t("patternService.motorFlag"),
          type: "boolean"
        }
      ]}
    />
  );
}
