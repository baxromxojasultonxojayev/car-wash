import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { useTranslation } from "react-i18next";

interface User {
  id: number;
  email: string;
  phone?: string;
  first_name: string;
  last_name: string;
  role: string;
  created_at?: string;
}

export default function UsersPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<User> = [
    { title: t("user.email"), dataIndex: "email" },
    { title: t("user.phone"), dataIndex: "phone" },
    { title: t("user.firstName"), dataIndex: "first_name" },
    { title: t("user.lastName"), dataIndex: "last_name" },
    { title: t("user.role"), dataIndex: "role" },
    { title: t("user.createdAt"), dataIndex: "created_at" }
  ];

  return (
    <EntityPage<User>
      entity="users"
      titleKey="nav.users"
      columns={columns}
      formFields={[
        { name: "email", label: t("user.email"), type: "text" },
        { name: "phone", label: t("user.phone"), type: "text" },
        { name: "first_name", label: t("user.firstName"), type: "text" },
        { name: "last_name", label: t("user.lastName"), type: "text" },
        { name: "role", label: t("user.role"), type: "text" }
      ]}
    />
  );
}
