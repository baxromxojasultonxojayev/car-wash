import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { Tag } from "antd";
import { useTranslation } from "react-i18next";

type KioskStatus = "free" | "payment" | "active" | "pause" | "finish" | "error" | "closed";

interface Kiosk {
  id: number;
  name: string;
  status: KioskStatus;
  is_active: boolean;
  controller_mac_address?: string;
}

export default function KiosksPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<Kiosk> = [
    { title: t("kiosk.name"), dataIndex: "name" },
    {
      title: t("kiosk.status"),
      dataIndex: "status",
      render: (v: KioskStatus) => <Tag>{v}</Tag>
    },
    {
      title: t("kiosk.isActive"),
      dataIndex: "is_active",
      render: (v: boolean) => (v ? <Tag color="green">ON</Tag> : <Tag color="red">OFF</Tag>)
    },
    {
      title: t("kiosk.controllerMac"),
      dataIndex: "controller_mac_address"
    }
  ];

  return (
    <EntityPage<Kiosk>
      entity="kiosks"
      titleKey="nav.kiosks"
      columns={columns}
      formFields={[
        { name: "name", label: t("kiosk.name"), type: "text" },
        {
          name: "status",
          label: t("kiosk.status"),
          type: "select",
          options: [
            "free",
            "payment",
            "active",
            "pause",
            "finish",
            "error",
            "closed"
          ].map((v) => ({ value: v, label: v }))
        },
        { name: "is_active", label: t("kiosk.isActive"), type: "boolean" },
        {
          name: "controller_mac_address",
          label: t("kiosk.controllerMac"),
          type: "text"
        }
      ]}
    />
  );
}
