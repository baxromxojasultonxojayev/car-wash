import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { useTranslation } from "react-i18next";

interface Payment {
  id: number;
  method: string;
  amount: number;
  paid_at?: string;
  rfid_card_number?: string;
  wash_session_id?: number;
}

export default function PaymentsPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<Payment> = [
    { title: t("payment.method"), dataIndex: "method" },
    { title: t("payment.amount"), dataIndex: "amount" },
    { title: t("payment.paidAt"), dataIndex: "paid_at" },
    { title: t("payment.rfidCard"), dataIndex: "rfid_card_number" },
    { title: t("payment.washSession"), dataIndex: "wash_session_id" }
  ];

  return (
    <EntityPage<Payment>
      entity="payments"
      titleKey="nav.payments"
      columns={columns}
      formFields={[
        { name: "method", label: t("payment.method"), type: "text" },
        { name: "amount", label: t("payment.amount"), type: "number" },
        { name: "paid_at", label: t("payment.paidAt"), type: "text" },
        {
          name: "rfid_card_number",
          label: t("payment.rfidCard"),
          type: "text"
        },
        {
          name: "wash_session_id",
          label: t("payment.washSession"),
          type: "number"
        }
      ]}
    />
  );
}
