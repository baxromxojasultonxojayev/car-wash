import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { useTranslation } from "react-i18next";

interface Advertisement {
  id: number;
  path: string;
  company_name?: string;
}

export default function AdvertisementsPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<Advertisement> = [
    { title: t("advertisement.path"), dataIndex: "path" },
    { title: t("advertisement.company"), dataIndex: "company_name" }
  ];

  return (
    <EntityPage<Advertisement>
      entity="advertisements"
      titleKey="nav.advertisements"
      columns={columns}
      formFields={[
        { name: "path", label: t("advertisement.path"), type: "text" },
        { name: "company_name", label: t("advertisement.company"), type: "text" }
      ]}
    />
  );
}
