import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { useTranslation } from "react-i18next";

interface Service {
  id: number;
  name: string;
  description?: string;
  company_name?: string;
}

export default function ServicesPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<Service> = [
    { title: t("service.name"), dataIndex: "name" },
    { title: t("service.description"), dataIndex: "description" },
    { title: t("service.company"), dataIndex: "company_name" }
  ];

  return (
    <EntityPage<Service>
      entity="services"
      titleKey="nav.services"
      columns={columns}
      formFields={[
        { name: "name", label: t("service.name"), type: "text" },
        { name: "description", label: t("service.description"), type: "text" },
        { name: "company_name", label: t("service.company"), type: "text" }
      ]}
    />
  );
}
