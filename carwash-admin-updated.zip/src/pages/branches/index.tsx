import EntityPage from "../../components/common/EntityPage";
import { ColumnsType } from "antd/es/table";
import { useTranslation } from "react-i18next";

interface Branch {
  id: number;
  name: string;
  description?: string;
  location?: string;
  company_name?: string;
}

export default function BranchesPage() {
  const { t } = useTranslation("common");

  const columns: ColumnsType<Branch> = [
    { title: t("branch.name"), dataIndex: "name" },
    { title: t("branch.description"), dataIndex: "description" },
    { title: t("branch.location"), dataIndex: "location" },
    { title: t("branch.company"), dataIndex: "company_name" }
  ];

  return (
    <EntityPage<Branch>
      entity="branches"
      titleKey="nav.branches"
      columns={columns}
      formFields={[
        { name: "name", label: t("branch.name"), type: "text" },
        { name: "description", label: t("branch.description"), type: "text" },
        { name: "location", label: t("branch.location"), type: "text" },
        { name: "company_name", label: t("branch.company"), type: "text" }
      ]}
    />
  );
}
