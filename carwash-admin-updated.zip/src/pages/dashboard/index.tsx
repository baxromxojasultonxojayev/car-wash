import { Card, Col, Row, Statistic } from "antd";
import { useTranslation } from "react-i18next";

export default function DashboardPage() {
  const { t } = useTranslation("common");

  return (
    <>
      <div className="page-header">
        <h2>{t("nav.dashboard")}</h2>
      </div>
      <Row gutter={[16, 16]}>
        <Col xs={24} sm={12} md={8} lg={6}>
          <Card>
            <Statistic title="Active kiosks" value={12} />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8} lg={6}>
          <Card>
            <Statistic title="Today sessions" value={34} />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8} lg={6}>
          <Card>
            <Statistic title="Payments today" value={1200000} suffix="UZS" />
          </Card>
        </Col>
      </Row>
    </>
  );
}
