import { RouteObject } from "react-router-dom";
import AppLayout from "../components/layout/AppLayout";
import DashboardPage from "../pages/dashboard";
import UsersPage from "../pages/users";
import CompaniesPage from "../pages/companies";
import BranchesPage from "../pages/branches";
import KiosksPage from "../pages/kiosks";
import RfidCardsPage from "../pages/rfid-cards";
import ServicesPage from "../pages/services";
import PatternsPage from "../pages/patterns";
import PatternServicesPage from "../pages/pattern-services";
import AdvertisementsPage from "../pages/advertisements";
import WashSessionsPage from "../pages/wash-sessions";
import PaymentsPage from "../pages/payments";

export const appRoutes: RouteObject[] = [
  {
    path: "/",
    element: <AppLayout />,
    children: [
      { path: "dashboard", element: <DashboardPage /> },
      { path: "users", element: <UsersPage /> },
      { path: "companies", element: <CompaniesPage /> },
      { path: "branches", element: <BranchesPage /> },
      { path: "kiosks", element: <KiosksPage /> },
      { path: "rfid-cards", element: <RfidCardsPage /> },
      { path: "services", element: <ServicesPage /> },
      { path: "patterns", element: <PatternsPage /> },
      { path: "pattern-services", element: <PatternServicesPage /> },
      { path: "advertisements", element: <AdvertisementsPage /> },
      { path: "wash-sessions", element: <WashSessionsPage /> },
      { path: "payments", element: <PaymentsPage /> }
    ]
  }
];
